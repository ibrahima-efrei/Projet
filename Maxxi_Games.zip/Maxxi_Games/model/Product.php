<?php
class Product
{
    private $products;

    public function __construct()
    {
        $this->products = [
            [
                'id' => 1,
                'name' => 'Manette',
                'description' => 'Description de la manette',
                'price' => 69.99,
                'image' => './view/img/Dualsense.webp'
            ],
            [
                'id' => 2,
                'name' => 'Ps5',
                'description' => 'Description de la PS5',
                'price' => 499.99,
                'image' => './view/img/ps5.webp'
            ],
            [
                'id' => 3,
                'name' => 'Casque VR2',
                'description' => 'Description du casque VR2',
                'price' => 599.99,
                'image' => './view/img/casque_vr.webp'
            ],
            [
                'id' => 4,
                'name' => 'FC 25',
                'description' => 'Description de FC 25',
                'price' => 69.99,
                'image' => './view/img/fc_25.avif'
            ],
            [
                'id' => 5,
                'name' => 'Astrobot',
                'description' => 'Description de Astrobot',
                'price' => 39.99,
                'image' => './view/img/Astrobot.jpeg'
            ],
            [
                'id' => 6,
                'name' => 'Horizon Forbidden West',
                'description' => 'Description de Forbidden West',
                'price' => 69.99,
                'image' => './view/img/horizon.avif'
            ]
        ];
    }

    public function getProducts()
    {
        return $this->products;
    }

    public function getProductById($id)
    {
        foreach ($this->products as $product) {
            if ($product['id'] == $id) {
                return $product;
            }
        }
        return null;
    }
}