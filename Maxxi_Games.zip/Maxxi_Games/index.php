<?php

session_start(); 

include('view/header.php');

include_once('controller/Router.php');

include('view/footer.php');
?>