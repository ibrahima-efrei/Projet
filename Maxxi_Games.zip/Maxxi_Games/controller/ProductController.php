<?php
include_once('model/Product.php');

class ProductController
{
    private $model;

    public function __construct()
    {
        $this->model = new Product();
    }

    public function home()
    {
        $products = $this->model->getProducts();
        include('view/products.php');
    }
}