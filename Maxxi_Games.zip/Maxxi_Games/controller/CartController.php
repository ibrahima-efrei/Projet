<?php
include_once('model/Product.php');

class CartController {
    private $productModel;

    public function __construct() {
        $this->productModel = new Product();
    }

    public function viewCart() {

        if (!isset($_SESSION['cart'])) {
            $_SESSION['cart'] = []; 
        }
        $cartProducts = $this->getCartProducts();

        include('view/cart.php');
    }

    public function addToCart($productId) {
        if (!isset($_SESSION['cart'])) {
            $_SESSION['cart'] = []; 
        }

        if (!in_array($productId, $_SESSION['cart'])) {
            $_SESSION['cart'][] = $productId; 
        }
    }

    public function removeFromCart($productId) {
        if (($key = array_search($productId, $_SESSION['cart'])) !== false) {
            unset($_SESSION['cart'][$key]); 
        }
    }

    public function getCartProducts() {
        $products = [];
        foreach ($_SESSION['cart'] as $productId) {
            $product = $this->productModel->getProductById($productId); // Récupère le produit par ID
            if ($product) {
                $products[] = $product;
            }
        }
        return $products;
    }
}