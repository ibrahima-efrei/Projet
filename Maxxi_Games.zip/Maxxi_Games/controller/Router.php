<?php

include_once('controller/ProductController.php');
include_once('controller/CartController.php');

$page = isset($_GET['page']) ? $_GET['page'] : 'home';

switch ($page) {
    case 'home':
        $productController = new ProductController();
        $productController->home();
        break;

    case 'cart': 
        $cartController = new CartController();
        $cartController->viewCart();
        break;

    case 'add_to_cart':
        if (isset($_GET['id'])) {
            $cartController = new CartController();
            $cartController->addToCart($_GET['id']);
            header('Location: index.php?page=cart');
            exit;
        }
        break;

    case 'remove_from_cart':
        if (isset($_GET['id'])) {
            $cartController = new CartController();
            $cartController->removeFromCart($_GET['id']);
            header('Location: index.php?page=cart');
            exit;
        }
        break;

    default:
        http_response_code(404);
        echo '404 Not Found';
        break;
}