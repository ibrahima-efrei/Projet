<?php

echo "<h1>404 Not Found</h1>";
echo "<p>La page que vous recherchez n'existe pas.</p>";
