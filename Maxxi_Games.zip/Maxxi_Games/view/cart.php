<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Panier</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <h1>Votre Panier</h1>
    
    <?php if (!empty($cartProducts)): ?>
        <div class="cart-list">
            <ul>
                <?php foreach ($cartProducts as $product): ?>
                    <li>
                        <h2><?php echo htmlspecialchars($product['name']); ?></h2>
                        <img src="<?php echo htmlspecialchars($product['image']); ?>" alt="<?php echo htmlspecialchars($product['name']); ?>">
                        <p><?php echo htmlspecialchars($product['description'] ?? 'Aucune description disponible'); ?></p>
                        <p>Prix : <?php echo htmlspecialchars($product['price']); ?> €</p>

                        <form action="index.php" method="GET">
                            <input type="hidden" name="page" value="remove_from_cart">
                            <input type="hidden" name="id" value="<?php echo $product['id']; ?>">
                            <button type="submit">Retirer du panier</button>
                        </form>
                    </li>
                <?php endforeach; ?>
            </ul>
        </div>
        <div class="cart-total">
            <h3>Total : 
                <?php
                    $total = 0;
                    foreach ($cartProducts as $product) {
                        $total += $product['price'];
                    }
                    echo htmlspecialchars($total) . " €";
                ?>
            </h3>
        </div>
    <?php else: ?>
        <p>Votre panier est vide.</p>
    <?php endif; ?>
</body>
</html>