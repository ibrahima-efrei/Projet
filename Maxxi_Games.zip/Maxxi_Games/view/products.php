<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Produits</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <h1>Maxxi games</h1>
    <div class="product-list">
        <?php if (!empty($products)): ?>
            <ul>
                <?php foreach ($products as $product): ?>
                    <li>
                        <h2><?php echo htmlspecialchars($product['name']); ?></h2>
                        <img src="<?php echo htmlspecialchars($product['image']); ?>" 
                        alt="<?php echo htmlspecialchars($product['name']); ?>" width="100px" >
                        <p><?php echo htmlspecialchars($product['description']); ?></p>
                        <p>Prix : <?php echo htmlspecialchars($product['price']); ?> €</p>
                        
                        <form action="index.php" method="GET">
                            <input type="hidden" name="page" value="add_to_cart">
                            <input type="hidden" name="id" value="<?php echo $product['id']; ?>">
                            <button type="submit">Ajouter au panier</button>
                        </form>
                    </li>
                <?php endforeach; ?>
            </ul>
        <?php else: ?>
            <p>Aucun produit trouvé.</p>
        <?php endif; ?>
    </div>
</body>
</html>