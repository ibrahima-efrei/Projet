<footer>
        <p>&copy; 2024 Mon E-commerce</p>
    </footer>
</body>
</html>